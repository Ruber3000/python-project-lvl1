#!/usr/bin/env python

print('Welcome to the Brain Games!')


def main():
    from ..games.progression import progress_range
    progress_range()


if __name__ == '__main__':
    main()
