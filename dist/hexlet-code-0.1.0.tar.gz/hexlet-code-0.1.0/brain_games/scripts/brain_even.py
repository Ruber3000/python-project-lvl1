#!/usr/bin/env python

print('Welcome to the Brain Games!')


def main():
    from ..games.even_code import even_find
    even_find()


if __name__ == '__main__':
    main()
