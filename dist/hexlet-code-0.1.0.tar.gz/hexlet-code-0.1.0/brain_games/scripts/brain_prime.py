#!/usr/bin/env python

print('Welcome to the Brain Games!')


def main():
    from ..games.prime_code import prime_try_find
    prime_try_find()


if __name__ == '__main__':
    main()
