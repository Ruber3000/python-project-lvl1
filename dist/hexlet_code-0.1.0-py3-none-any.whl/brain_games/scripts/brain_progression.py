#!/usr/bin/env python

print('Welcome to the Brain Games!')


def main():
    from ..games.progression_code import progress_gange
    progress_gange()


if __name__ == '__main__':
    main()
