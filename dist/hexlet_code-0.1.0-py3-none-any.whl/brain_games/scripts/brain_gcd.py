#!/usr/bin/env python

print('Welcome to the Brain Games!')


def main():
    from ..games.gcd_code import nod_function
    nod_function()


if __name__ == '__main__':
    main()
